#include<iostream>
#include<cmath>
using namespace std;
int partition(int a[],int low,int high){
	int pivot = a[high];
	int left = low;
	int right = high - 1;
	while(left<=right){
		while(a[left]<pivot) left++;
		while(a[right]>pivot) right--;
		if (left<right) {
			swap (a[left],a[right]);
		    left++;
		    right--;
		}
		break;
	}
	swap(a[left],a[high]);
	return left;
}
void QuickSort(int a[],int low,int high){
	if (low<high){
		int p = partition(a,low,high);
		QuickSort(a,low,p-1);
		QuickSort(a,p+1,high);
	}
}
void PrintArray(int a[],int n){
	for (int i=0;i<n;i++){
		cout<<a[i]<<" ";
	}
}

int main(){
	int a[] = {10,30,30,-34,-543,43543,70};
	int n = sizeof(a)/sizeof(int);
	cout<<n<<endl;
	QuickSort(a,0,n-1);
	PrintArray(a,n);
}
